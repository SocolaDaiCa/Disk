function rot47(x) {
	var s = [];
	for (var i = 0; i < x.length; i++) {
		var j = x.charCodeAt(i);
		if ((j >= 33) && (j <= 126)) {
			s[i] = String.fromCharCode(33 + ((j + 14) % 94));
		} else {
			s[i] = String.fromCharCode(j);
		}
	}
	return s.join('');
}

function _rot47(args){
	if(args=="") //Check syntax
	{
		_ret("The correct syntax is: '<b class='hlight'>rot47</b> text'",false);
	}else{
		_ret(rot47(args));
	}
}    