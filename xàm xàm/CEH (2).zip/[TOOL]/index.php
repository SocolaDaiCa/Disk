<html xmlns="http://www.w3.org/1999/xhtml"><head>
 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<title>[VN/ Tools]</title>
	<style>@import url('/[DATA]/[CSS]/tools.css');</style>
	<script data-main="/[DATA]/[JS]/tools.js" src="/[DATA]/[JS]/require.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="tools" src="https://ceh.vn/[DATA]/[JS]/tools.js"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery" src="../[DATA]/[JS]/[LIB]/jquery-1.12.0.min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="detectmobilebrowser" src="../[DATA]/[JS]/[LIB]/detectmobilebrowser.js"></script></head>
<body>
<div id="preloader" style="display: none;"><div id="status" style="display: none;"></div></div>
<div id="container"><br>
&nbsp; &nbsp; &nbsp; <b class="hlight">[Warning]</b> Sorry, Data not available
</div>

<!-- PhME4 -->
<noscript>&lt;meta http-equiv='refresh' content='0;url=/[NOSCRIPT]/'&gt; </noscript></body></html>