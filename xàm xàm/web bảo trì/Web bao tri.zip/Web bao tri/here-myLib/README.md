Target-DIMA--Coming-Soon-Page-
==============================

Target-DIMA is a creative under construction / coming soon theme. If you are working in a new website, this template is perfect for you.

[Demo](http://localhost/preview/?theme=target)
