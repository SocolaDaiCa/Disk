Target-DIMA--Coming-Soon-Page-
+==============================

Target-DIMA is a creative under construction / coming soon theme. If you are working in a new website, this template is perfect for you.

+[Demo](http://pixeldima.com/preview/?theme=target)
