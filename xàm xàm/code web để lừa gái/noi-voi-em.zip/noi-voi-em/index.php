﻿<html>
<head>
<title><?php if($_GET['anh']==null) echo 'ANH'; else echo $_GET['anh']; ?> ♥ <?php if($_GET['em']==null) echo 'EM'; else echo $_GET['em']; ?> - CHỈ VẬY THÔI</title>
<link rel="shortcut icon" href="favicon.ico" type="image/png">
<link rel="shortcut icon" type="image/png" href="favicon.ico" />
<link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
	<script src="js/jquery.1.7.2.min.js" type="text/javascript"></script>
	<script type="text/javascript" src="js/jquery-ui-1.8.23.custom.min.js"></script>
	<script type="text/javascript" src="js/jquery.spritely-0.6.1.js"></script>
	<script src="js/jquery.global.js" type="text/javascript"></script>
	<style type="text/css">
	</style>
</head>
<body>
<article id="cloud">
<p><font color="#d64f1e"><?php if($_GET['anh']==null) echo 'ANH'; else echo $_GET['anh']; ?></font> <font color="#c41818">♥</font> <font color="#db3376"><?php if($_GET['em']==null) echo 'EM'; else echo $_GET['em']; ?></font> - <font color="#fff">CHỈ VẬY THÔI</font></p>
</article>
<footer id="city"></footer>
<div id="dapxe"><center><embed width="500" height="500"  wmode="transparent" menu="false" quality="high" type="application/x-shockwave-flash" src="dapxe.swf" pluginspage="http://www.macromedia.com/go/getflashplayer"/></center></div>
<div id="duong"><p>&copy; 2017 <font color="#d64f1e"><b> <?php  echo $_GET['anh']; ?></b></font> - Dành tặng cho <font color="#db3376"><b>♥ <?php  echo $_GET['em']; ?></b></font></br></br>
Baby baby chỉ cần nhìn thấy em cười chút thôi, là lòng anh đã trót nhớ nhung rồi</br>
Baby baby chỉ cần em ghé qua đây một lần thôi, là anh đã biết trót yêu em rồi ♥...</br>

<iframe src="http://www.nhaccuatui.com/mh/background/kXP2dJBgTuqG" width="1" height="1" frameborder="0" allowfullscreen></iframe>
</body>
</html>