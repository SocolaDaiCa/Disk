 <?php
$api = $_POST[loai];
$duma = $_POST[listacc];
if($api && $duma){
$nhan= explode("\n", $_POST[listacc]);
foreach($nhan as $acc){
$email = explode("|",trim($acc));
$username = $email[0];
$password = $email[1];
if($api == 1){
$token = json_decode(auto('https://botlike24h.com/gettoken/iphone.php?u='.$username.'&p='.urlencode($password).''),true);  
				 if(isset($token['error_msg'])) 
				 {
					 $data = json_decode($token['error_data'], true);
					 $kubon['error_msg'] = $data['error_message'];
					 echo json_encode($kubon);
				 }  
						 else if(isset($token['access_token']))  
						 {
							$kubon['access_token'] = $token['access_token'];
							 Echo json_encode($kubon);		
						 }
}
else if($api == 2)
    {
		$token = json_decode(auto('https://botlike24h.com/gettoken/android.php?u='.$username.'&p='.urlencode($password).''),true);  
	             if(isset($token['error_msg'])) 
				 {
					 $data = json_decode($token['error_data'], true);
					 $kubon['error_msg'] = $data['error_message'];
					 echo json_encode($kubon);
				 }   
						else if(isset($token['access_token']))  
						 {
							$kubon['access_token'] = $token['access_token'];
							 Echo json_encode($kubon);		
						 }
	}
}
}
function auto($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>