<?php

class Repository extends Service
{
}

?>
