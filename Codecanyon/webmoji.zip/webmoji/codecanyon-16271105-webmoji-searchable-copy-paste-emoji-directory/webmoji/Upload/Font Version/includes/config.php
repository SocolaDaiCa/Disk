<?php

$config['site_title'] = 'WebEmoji'; // The title to use on pages

$config['site_description'] = 'Search and copy over 1,000 emoji to use on facebook, twiter and more!'; // The meta description

$config['site_name'] = 'WebEmoji'; // The name of your website 

$config['site_url'] = 'http://emberthemes.net/demo/emoji'; // URL of your website

$config['tweet_message'] = 'Super awesome tweet message!'; // Tweet Message

?>