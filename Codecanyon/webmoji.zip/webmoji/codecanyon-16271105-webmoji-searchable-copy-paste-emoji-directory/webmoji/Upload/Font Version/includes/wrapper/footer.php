<div id="footer">
<div class="container">
<span class="pull-left">&copy; <?php echo $config['site_name']; ?> 2016.</span>
<span class="pull-right"><a href="http://emberthemes.net"><img src="http://emberthemes.net/demo/placeholderr/assets/img/foot-icon.png" alt="EmberThemes - PHP scripts, wordpress plugins and HTML templates"></a></span>
</div>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js" type="text/javascript"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/clipboard.min.js"></script>
<script src="assets/js/toastr.min.js"></script>
<script src="assets/js/smooth.min.js"></script>
<script src="assets/js/pace.min.js"></script>
<script src="assets/js/ember.min.js"></script>

<a href="#" class="back-to-top">Back to Top</a>
</body>
</html>