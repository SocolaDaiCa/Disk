<?php
function curl($url){
	$ch = @curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	$head[] = "Connection: keep-alive";
	$head[] = "Keep-Alive: 300";
	$head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
	$head[] = "Accept-Language: en-us,en;q=0.5";
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
	$page = curl_exec($ch);
	curl_close($ch);
	return $page;
}
function Drive_direct($curl){
	preg_match('/(?:https?:\/\/)?(?:[\w\-]+\.)*(?:drive|docs)\.google\.com\/(?:(?:folderview|open|uc)\?(?:[\w\-\%]+=[\w\-\%]*&)*id=|(?:folder|file|document|presentation)\/d\/|spreadsheet\/ccc\?(?:[\w\-\%]+=[\w\-\%]*&)*key=)([\w\-]{28,})/i', $curl , $id);
	$get = curl('https://mail.google.com/e/get_video_info?docid='.$id[1]);
    $remove = str_replace('\/','/',$get);
	$cat = explode('fmt_stream_map=', $get); 
	$cat = explode('&', $cat[1]);
	$cat = explode(',', urldecode($cat[0]));
	foreach($cat as $link){
		$cat = explode('|', $link);
		$links = str_replace(array('videoplayback?id','&app=explorer'), array('videoplayback?api=api.locphim.com&id',''), urldecode($cat[1]));
		$xuly_link = preg_replace(["/\/[^\/]+\.google\.com/", "/\/[^\/]+\.googlevideo\.com/", "/ipbits=\d{2}/","/&driveid=(.*)/"],["/redirector.googlevideo.com", "/redirector.googlevideo.com", "ipbits=12",""],$links);
		if($cat[0] == 37) {$cur1080p = $xuly_link;}
		if($cat[0] == 22) {$cur720p = $xuly_link;}
		if($cat[0] == 59) {$cur480p = $xuly_link;}
		if($cat[0] == 18) {$cur360p = $xuly_link;}
	}
	if(isset($cur1080p)){
		$locphim .= '[1080p]</br>'.$cur1080p.''; 
        $locphim .= '[720p]</br>'.$cur720p.'';
        $locphim .= '[480p]</br>'.$cur480p.'';
        $locphim .= '[360p]</br>'.$cur360p.'';
	} elseif(isset($cur720p)){
        $locphim .= '[720p]</br>'.$cur720p.'';
        $locphim .= '[480p]</br>'.$cur480p.'';
        $locphim .= '[360p]</br>'.$cur360p.'';
	} elseif(isset($cur480p)){
        $locphim .= '[480p]</br>'.$cur480p.'';
        $locphim .= '[360p]</br>'.$cur360p.'';
	} elseif(isset($cur360p)){
		$locphim .= '[360p]</br>'.$cur360p.'';
	} else {
		$locphim .= 'Lỗi Kìa Mấy Mẹ :v ahihi đồ ngốc :v';
	}
	return $locphim;
}
$url = $_REQUEST['url'];
if(isset($url)) {
echo Drive_direct($url);
}
?>