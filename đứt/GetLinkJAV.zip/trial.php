<?php

$url = curl($_POST['link']);
if(preg_match('#<a onclick="(.+?)" href="(.+?)"><span>HD Quality</span>(.+?)</a></li><li><a onclick="(.+?)" href="(.+?)"><span>Normal Quality</span>(.+?)</a></li><li><a onclick="(.+?)" href="(.+?)"><span>Low Quality</span>(.+?)</a></li>#is',$url, $_puaru))
{
    /*
$video= curl($_puaru[5]);
if(preg_match('# <meta http-equiv="refresh" content="1;url=(.+?)" />#is',$video, $_phatvideo))
{
    echo '<video width="100%" controls>
  <source src="'.$_phatvideo[1].'" type="video/mp4">
</video>';
}
*/
   echo '<b><font color="red">['.date("H:i:s").']:<br>  <br><center>
<a href="/Puaru.php?link='.base64_encode(base64_encode(base64_encode(chuyen($_puaru[2])))).'&xem=puaru" target="_blank"><button type="button" class="btn btn-success">Xem HD Quality '.chuyen($_puaru[3]).'</button></a> - <a href="/Puaru.php?link='.base64_encode(base64_encode(base64_encode($_puaru[2]))).'&download=puaru" target="_blank"><button type="button" class="btn btn-success">Download HD Quality - '.chuyen($_puaru[3]).'</button></a><br><br>
   <a href="/Puaru.php?link='.base64_encode(base64_encode(base64_encode(chuyen($_puaru[5])))).'&xem=puaru" target="_blank"><button type="button" class="btn btn-success">Xem Normal Quality '.chuyen($_puaru[6]).'</button></a> - <a href="/Puaru.php?link='.base64_encode(base64_encode(base64_encode($_puaru[5]))).'&download=puaru" target="_blank"><button type="button" class="btn btn-success">Download Normal Quality - '.chuyen($_puaru[6]).'</button></a><br><br>
   <a href="/Puaru.php?link='.base64_encode(base64_encode(base64_encode(chuyen($_puaru[8])))).'&xem=puaru" target="_blank"><button type="button" class="btn btn-success">Xem Low Quality '.chuyen($_puaru[9]).'</button></a> - <a href="/Puaru.php?link='.base64_encode(base64_encode(base64_encode($_puaru[8]))).'&download=puaru" target="_blank"><button type="button" class="btn btn-success">Download Low Quality - '.chuyen($_puaru[9]).'</button></a><br></font></b></center>';
}
else
{
  echo '<b><font color="red">['.date("H:i:s").']: LINK KHÔNG HỢP LỆ HOẶC KHÔNG GET ĐƯỢC PHIM, HỆ THỐNG CHỈ HỔ TRỢ JAVHD.COM </font></b>';
}
function chuyen($content)
{
    $content= str_replace('download', 'playback', $content);
    return $content;
}
function curl($url)
{
    $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, 'locale=en; JAVSESSID=sco1phs98p04m79lh9svk7qnq3; uid=user37106; lt=1483193780; slt=06cebc922f75e0018f091a51daee06ef; t_sid=sco1phs98p04m79lh9svk7qnq3; t_scr=1483193763; user_lang=en; nats=MC4wLjIuMi4wLjAuMC4wLjA; nats_cookie=http%253A%252F%252Fjavhd.com%252Fen; nats_unique=MC4wLjIuMi4wLjAuMC4wLjA; nats_sess=7d5aa1ad021320194bc36c9c07e23188; form_prices_en=1; last_visited_set=19475; _ga=GA1.2.1135802169.1483193374; feid=34b27a376da4ed848dbf27c15b4d001e; fesid=e88fa2c1ab335bd2a45c1d049200e0aa; atas_uid=');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $page = curl_exec($ch);
    curl_close($ch);
    return $page;
} 
?>