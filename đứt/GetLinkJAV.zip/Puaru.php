<meta charset="utf-8">
<?php
$url= curl(base64_decode(base64_decode(base64_decode($_GET['link']))));
if(preg_match('# <meta http-equiv="refresh" content="1;url=(.+?)" />#is',$url, $_puaru))
{
    if($_GET['download']) echo '<!DOCTYPE html>
<html lang="en">
<head>
  <title>Get Link JAVHD.COM By Puaru</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">Get Link JAVHD.COM</div>
      <div class="panel-body">
      <center>
 <a href="'.$_puaru[1].'"><button type="button" class="btn btn-success">Click Để Tải Về</button></a></center>

 </div>
    </div>
</div></div></body>
</html>';
    if($_GET['xem']) echo '<!DOCTYPE html>
<html lang="en">
<head>
  <title>Get Link JAVHD.COM By Puaru</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">Get Link JAVHD.COM</div>
      <div class="panel-body"><video width="100%" controls>
  <source src="'.$_puaru[1].'" type="video/mp4">
</video></div>
    </div>
</div></div></body>
</html>';

}
function curl($url)
{
    $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, 'locale=en; JAVSESSID=sco1phs98p04m79lh9svk7qnq3; uid=user37106; lt=1483193780; slt=06cebc922f75e0018f091a51daee06ef; t_sid=sco1phs98p04m79lh9svk7qnq3; t_scr=1483193763; user_lang=en; nats=MC4wLjIuMi4wLjAuMC4wLjA; nats_cookie=http%253A%252F%252Fjavhd.com%252Fen; nats_unique=MC4wLjIuMi4wLjAuMC4wLjA; nats_sess=7d5aa1ad021320194bc36c9c07e23188; form_prices_en=1; last_visited_set=19475; _ga=GA1.2.1135802169.1483193374; feid=34b27a376da4ed848dbf27c15b4d001e; fesid=e88fa2c1ab335bd2a45c1d049200e0aa; atas_uid=');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $page = curl_exec($ch);
    curl_close($ch);
    return $page;
} 
?>