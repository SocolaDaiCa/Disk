<!DOCTYPE html>
<html lang="en">
<head>
  <title>Get Link JAVHD.COM By Puaru</title>
  <meta charset="utf-8">
  <meta property="og:image" content="http://i.imgur.com/NF9Hyo4.png" />
  <meta name="description" content="GetLink JAVHD Free Không Quảng Cáo!" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
 
<div class="container">
  <h2>Get Link JAVHD.COM</h2>
  <div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">Get Link JAVHD.COM</div>
      <div class="panel-body">

<div class="form-group">
  <label for="pwd">Link Video:</label>
  <input type="text" class="form-control" id="link" value="http://javhd.com/en/id/18858/miku-ohashi-enjoys-her-first-time-creampie-asian-end">
</div>
<button type="button" class="btn btn-danger" onclick="Puaru_Active()" >Get Link</button>
<p>
<li id="trave" class="list-group-item">Chào Các ACE Đồng Dâm :*<br>Hệ Thống Chỉ Hỗ Trợ JAVHD.COM</li></p>

</div>
    </div>
</div>

<script>
function Puaru_Active() {
var http = new XMLHttpRequest();
var link = document.getElementById("link").value;
var url = "trial.php";
var params = "link="+link+"";
http.open("POST", url, true);
http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

http.onreadystatechange = function() {
    if(http.readyState == 4 && http.status == 200) {
      document.getElementById("trave").innerHTML = http.responseText;        
    }
}
http.send(params);
}
</script>

</body>
</html>