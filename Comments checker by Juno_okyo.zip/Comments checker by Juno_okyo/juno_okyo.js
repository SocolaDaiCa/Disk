/* Developed by Juno_okyo | Copyright (C) 2017 J2TeaM */
(function() {
  new Vue({
    el: "#juno_okyo",
    data: {
      endpoint: "https://graph.facebook.com/v2.8/",
      access_token: "YOUR_ACCESS_TOKEN",
      url: null,
      comments: [],
      spam: [],
      error: !1,
      loading: !1
    },
    methods: {
      onSubmit: function() {
        if (null !== this.url)
          if (this.isFacebookUrl()) {
            this.error = !1;
            var a = this.getPostId();
            !1 !== a && (this.loading = !0, this.$http.get(this.endpoint + a + "/comments?limit=500&access_token=" +
              this.access_token).then(function(a) {
              return a.json()
            }, function(a) {
              return a.json()
            }).then(function(a) {
              if (a.data) {
                var c = [],
                  b = this;
                a.data.map(function(a) {
                  b.isSpam(a.message) && c.push(a)
                });
                this.comments = c
              }
              this.loading = !1
            }))
          } else this.error = !0
      },
      isFacebookUrl: function() {
        try {
          return (new URL(this.url)).hostname.includes(".facebook.com")
        } catch (a) {
          return !1
        }
      },
      getPostId: function() {
        if (this.url.includes("/")) try {
          return this.url.split("/")[6]
        } catch (a) {
          return !1
        } else return !1
      },
      isSpam: function(a) {
        return ".{,{;{'{..{...{....{.....{cham{ch\u1ea5m{ch\u1ea5m m\u00fat".split("{").includes(a.toLowerCase())
      }
    }
  })
})();