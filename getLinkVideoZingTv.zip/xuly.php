<?php
include'config.php';

$link = $_GET['link'];

if(!$link) {
die('<font color="red"><b> Nhập LINK vô đi nhóc</b></font>');
}
$url= get($link);
if(preg_match_all('/video720 = "(.+?)";/',$url, $_link))
    {
        $_720 = $_link[1][0];
      echo'<p><font color="red">Link 720p</font></p>';
      echo'<input type="text" id="linkget" class="form-control" value="'.$_720.'"/>';
    }
if(preg_match_all('/video1080 = "(.+?)";/',$url, $_link))
    {
        $_1080 = $_link[1][0];
      echo'<p><font color="red">Link 1080p</font></p>';
      echo'<input type="text" id="linkget" class="form-control" value="'.$_1080.'"/>';
    }

if(!$_720 &&!$_1080) {
die('<font color="red"><b> Không thể GET link này ! :(</b></font>');
}

?>